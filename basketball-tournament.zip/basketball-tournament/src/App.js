import { useState, useCallback } from "react";

/* ─── 設定區：修改這裡來客製你的活動 ─────────────────── */
const CONFIG = {
  eventName: "SLAM DUNK CUP",
  eventSubtitle: "2024 籃球錦標賽",
  adminPassword: "bball2024",   // ← 上線前請改成自己的密碼
  teams: [
    "火箭隊", "雷霆隊", "湖人隊", "勇士隊",
    "公牛隊", "熱火隊", "凱爾特人", "76人隊",
    "快艇隊", "爵士隊", "灰熊隊", "馬刺隊",
    "開拓者", "老鷹隊", "魔術隊", "黃蜂隊",
  ],
};

/* ─── 初始賽程 ──────────────────────────────────────── */
const INITIAL_SCHEDULE = [
  { id: 1,  time: "09:00", court: "A場", team1: "火箭隊",  team2: "雷霆隊",   round: "16強", status: "待賽" },
  { id: 2,  time: "09:00", court: "B場", team1: "湖人隊",  team2: "勇士隊",   round: "16強", status: "待賽" },
  { id: 3,  time: "10:00", court: "A場", team1: "公牛隊",  team2: "熱火隊",   round: "16強", status: "待賽" },
  { id: 4,  time: "10:00", court: "B場", team1: "凱爾特人",team2: "76人隊",   round: "16強", status: "待賽" },
  { id: 5,  time: "11:00", court: "A場", team1: "快艇隊",  team2: "爵士隊",   round: "16強", status: "待賽" },
  { id: 6,  time: "11:00", court: "B場", team1: "灰熊隊",  team2: "馬刺隊",   round: "16強", status: "待賽" },
  { id: 7,  time: "13:00", court: "A場", team1: "開拓者",  team2: "老鷹隊",   round: "16強", status: "待賽" },
  { id: 8,  time: "13:00", court: "B場", team1: "魔術隊",  team2: "黃蜂隊",   round: "16強", status: "待賽" },
  { id: 9,  time: "14:30", court: "A場", team1: "TBD",     team2: "TBD",      round: "八強", status: "未定" },
  { id: 10, time: "14:30", court: "B場", team1: "TBD",     team2: "TBD",      round: "八強", status: "未定" },
  { id: 11, time: "15:30", court: "A場", team1: "TBD",     team2: "TBD",      round: "八強", status: "未定" },
  { id: 12, time: "15:30", court: "B場", team1: "TBD",     team2: "TBD",      round: "八強", status: "未定" },
  { id: 13, time: "16:30", court: "A場", team1: "TBD",     team2: "TBD",      round: "四強", status: "未定" },
  { id: 14, time: "16:30", court: "B場", team1: "TBD",     team2: "TBD",      round: "四強", status: "未定" },
  { id: 15, time: "17:30", court: "A場", team1: "TBD",     team2: "TBD",      round: "決賽", status: "未定" },
];

const INITIAL_ANNOUNCEMENTS = [
  { id: 1, time: "08:30", text: "🏀 歡迎參加 2024 籃球錦標賽！報到處在大門右側，請攜帶報名證。" },
  { id: 2, time: "08:45", text: "📋 所有隊伍請於比賽前 15 分鐘到指定場地集合熱身，遲到視同棄權。" },
];

/* ─── 建立16隊單淘汰賽制 ───────────────────────────── */
function buildBracket(teams) {
  const r1 = teams.reduce((acc, _, i) => {
    if (i % 2 === 0) acc.push({ id: `r1-${i/2}`, team1: teams[i], team2: teams[i+1], score1: null, score2: null, winner: null });
    return acc;
  }, []);
  return [
    { key: "r1", name: "16強", matches: r1 },
    { key: "r2", name: "八強", matches: Array.from({length:4},(_,i)=>({ id:`r2-${i}`, team1:null, team2:null, score1:null, score2:null, winner:null })) },
    { key: "r3", name: "四強", matches: Array.from({length:2},(_,i)=>({ id:`r3-${i}`, team1:null, team2:null, score1:null, score2:null, winner:null })) },
    { key: "final", name: "決賽", matches: [{ id:"final-0", team1:null, team2:null, score1:null, score2:null, winner:null }] },
  ];
}

function propagateWinners(rounds) {
  const next = rounds.map(r => ({ ...r, matches: r.matches.map(m => ({ ...m })) }));
  for (let ri = 0; ri < next.length - 1; ri++) {
    const winners = next[ri].matches.map(m => m.winner);
    for (let mi = 0; mi < next[ri+1].matches.length; mi++) {
      next[ri+1].matches[mi].team1 = winners[mi*2] ?? null;
      next[ri+1].matches[mi].team2 = winners[mi*2+1] ?? null;
      // Reset score if teams changed
      if (!next[ri+1].matches[mi].team1 || !next[ri+1].matches[mi].team2) {
        next[ri+1].matches[mi].score1 = null;
        next[ri+1].matches[mi].score2 = null;
        next[ri+1].matches[mi].winner = null;
      }
    }
  }
  return next;
}

/* ─── 顏色常數 ──────────────────────────────────────── */
const C = {
  bg: "#030712",
  surface: "rgba(255,255,255,0.04)",
  border: "rgba(255,255,255,0.08)",
  orange: "#f97316",
  orangeDim: "rgba(249,115,22,0.15)",
  gold: "#fbbf24",
  green: "#4ade80",
  text: "#f8fafc",
  muted: "#94a3b8",
  dim: "#475569",
};

/* ─── 스타일 helpers ─────────────────────────────────── */
const card = (extra={}) => ({
  background: C.surface,
  border: `1px solid ${C.border}`,
  borderRadius: 16,
  backdropFilter: "blur(8px)",
  ...extra,
});

/* ─── MatchCard ─────────────────────────────────────── */
function MatchCard({ match, isAdmin, onUpdate }) {
  const [editing, setEditing] = useState(false);
  const [s1, setS1] = useState("");
  const [s2, setS2] = useState("");

  const isPlaceholder = !match.team1 && !match.team2;
  const isDone = !!match.winner;
  const isLive = match.score1 !== null && !isDone;

  function openEdit() { setS1(match.score1 ?? ""); setS2(match.score2 ?? ""); setEditing(true); }

  function save() {
    const n1 = parseInt(s1), n2 = parseInt(s2);
    if (isNaN(n1) || isNaN(n2) || n1 < 0 || n2 < 0) return;
    onUpdate(match.id, n1, n2);
    setEditing(false);
  }

  const t1 = match.team1 || "待定";
  const t2 = match.team2 || "待定";

  const borderColor = isDone ? C.orange : isLive ? C.gold : C.border;
  const statusDot = isDone ? C.orange : isLive ? C.gold : C.dim;
  const statusLabel = isDone ? "結束" : isLive ? "進行中" : isPlaceholder ? "" : "待賽";

  return (
    <div style={{
      ...card({ border: `1px solid ${borderColor}`, background: isDone ? "rgba(249,115,22,0.08)" : C.surface }),
      padding: "12px 14px",
      minWidth: 180,
      position: "relative",
      transition: "border-color 0.3s",
    }}>
      {statusLabel && (
        <div style={{ position:"absolute", top:8, right:10, display:"flex", alignItems:"center", gap:4 }}>
          <div style={{ width:6, height:6, borderRadius:"50%", background:statusDot, ...(isLive && { animation:"pulse 1.5s infinite" }) }} />
          <span style={{ fontSize:10, color:statusDot, fontWeight:700 }}>{statusLabel}</span>
        </div>
      )}
      {/* Team 1 */}
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:6 }}>
        <span style={{ fontSize:13, fontWeight: match.winner===t1 ? 700 : 400, color: isPlaceholder ? C.dim : match.winner===t1 ? C.orange : C.text }}>{t1}</span>
        {!isPlaceholder && <span style={{ fontFamily:"monospace", fontSize:20, fontWeight:700, color: match.winner===t1 ? C.orange : C.muted, marginLeft:12 }}>{match.score1 ?? "–"}</span>}
      </div>
      <div style={{ borderTop:`1px solid ${C.border}`, margin:"4px 0" }} />
      {/* Team 2 */}
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginTop:6 }}>
        <span style={{ fontSize:13, fontWeight: match.winner===t2 ? 700 : 400, color: isPlaceholder ? C.dim : match.winner===t2 ? C.orange : C.text }}>{t2}</span>
        {!isPlaceholder && <span style={{ fontFamily:"monospace", fontSize:20, fontWeight:700, color: match.winner===t2 ? C.orange : C.muted, marginLeft:12 }}>{match.score2 ?? "–"}</span>}
      </div>

      {/* Admin controls */}
      {isAdmin && !isPlaceholder && (
        <div style={{ marginTop:10 }}>
          {editing ? (
            <div style={{ display:"flex", gap:6, alignItems:"center", flexWrap:"wrap" }}>
              <input type="number" min="0" value={s1} onChange={e=>setS1(e.target.value)}
                placeholder={t1}
                style={{ width:54, background:"#1e293b", border:`1px solid ${C.orange}`, borderRadius:8, padding:"3px 6px", color:C.text, textAlign:"center", fontSize:13 }} />
              <span style={{ color:C.dim, fontSize:12 }}>vs</span>
              <input type="number" min="0" value={s2} onChange={e=>setS2(e.target.value)}
                placeholder={t2}
                style={{ width:54, background:"#1e293b", border:`1px solid ${C.orange}`, borderRadius:8, padding:"3px 6px", color:C.text, textAlign:"center", fontSize:13 }} />
              <button onClick={save} style={{ background:C.orange, color:"#fff", border:"none", borderRadius:8, padding:"3px 10px", fontSize:12, fontWeight:700 }}>確認</button>
              <button onClick={()=>setEditing(false)} style={{ background:"transparent", color:C.muted, border:"none", fontSize:12 }}>取消</button>
            </div>
          ) : (
            <button onClick={openEdit} style={{
              width:"100%", background:"transparent", border:`1px solid ${C.orangeDim}`, borderRadius:8,
              color:C.orange, fontSize:12, padding:"5px 0", cursor:"pointer", marginTop:2,
              transition:"background 0.2s",
            }}
            onMouseEnter={e=>e.target.style.background=C.orangeDim}
            onMouseLeave={e=>e.target.style.background="transparent"}
            >✏️ 更新比分</button>
          )}
        </div>
      )}
    </div>
  );
}

/* ─── BracketView ───────────────────────────────────── */
function BracketView({ rounds, isAdmin, onUpdate }) {
  const roundColors = { "16強":"#60a5fa", "八強":"#a78bfa", "四強":"#f472b6", "決賽":C.orange };
  return (
    <div style={{ overflowX:"auto", paddingBottom:16 }}>
      <div style={{ display:"flex", gap:20, minWidth:"max-content", alignItems:"center" }}>
        {rounds.map((round, ri) => {
          const gap = Math.pow(2, ri) * 16;
          return (
            <div key={round.key} style={{ display:"flex", flexDirection:"column", alignItems:"center" }}>
              <div style={{ fontSize:11, fontWeight:800, letterSpacing:"0.2em", color:roundColors[round.name]||C.muted, marginBottom:12, textTransform:"uppercase" }}>
                {round.name}
              </div>
              <div style={{ display:"flex", flexDirection:"column", gap: `${gap}px` }}>
                {round.matches.map(match => (
                  <MatchCard key={match.id} match={match} isAdmin={isAdmin} onUpdate={onUpdate} />
                ))}
              </div>
            </div>
          );
        })}
        {/* Champion display */}
        {(() => {
          const champion = rounds[3]?.matches[0]?.winner;
          return champion ? (
            <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:8, padding:"16px 20px", background:"rgba(251,191,36,0.1)", border:`2px solid ${C.gold}`, borderRadius:16 }}>
              <div style={{ fontSize:24 }}>🏆</div>
              <div style={{ fontSize:11, color:C.gold, fontWeight:800, letterSpacing:"0.15em" }}>冠軍</div>
              <div style={{ fontSize:16, color:C.gold, fontWeight:900 }}>{champion}</div>
            </div>
          ) : null;
        })()}
      </div>
    </div>
  );
}

/* ─── ScheduleView ──────────────────────────────────── */
function ScheduleView({ schedule, isAdmin, onStatusUpdate }) {
  const statusStyles = {
    "待賽":    { bg:"#1e293b", color:C.muted },
    "進行中": { bg:"rgba(251,191,36,0.2)", color:C.gold },
    "結束":   { bg:"rgba(249,115,22,0.2)", color:C.orange },
    "未定":   { bg:"rgba(255,255,255,0.04)", color:C.dim },
  };
  const roundColor = { "16強":"#60a5fa", "八強":"#a78bfa", "四強":"#f472b6", "決賽":C.orange };

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
      {schedule.map(item => {
        const st = statusStyles[item.status] || statusStyles["未定"];
        return (
          <div key={item.id} className="fade-in" style={{
            ...card(),
            display:"flex", alignItems:"center", gap:12, padding:"12px 16px",
            transition:"background 0.2s",
          }}>
            <div style={{ fontFamily:"monospace", fontWeight:700, color:C.orange, fontSize:14, minWidth:44 }}>{item.time}</div>
            <div style={{ background:"#1e293b", color:C.muted, fontSize:11, borderRadius:6, padding:"2px 8px", minWidth:32, textAlign:"center" }}>{item.court}</div>
            <div style={{ flex:1, fontSize:14, color:C.text }}>
              <span style={{ fontWeight:600 }}>{item.team1}</span>
              <span style={{ color:C.dim, margin:"0 6px" }}>vs</span>
              <span style={{ fontWeight:600 }}>{item.team2}</span>
            </div>
            <div style={{ fontSize:11, fontWeight:700, color:roundColor[item.round]||C.dim, minWidth:30, textAlign:"right", display:"none" }} className="round-label">{item.round}</div>
            {isAdmin ? (
              <select value={item.status} onChange={e=>onStatusUpdate(item.id, e.target.value)}
                style={{ background:"#1e293b", border:`1px solid ${C.orange}`, borderRadius:8, color:C.text, fontSize:12, padding:"4px 8px", cursor:"pointer" }}>
                {["待賽","進行中","結束","未定"].map(s=><option key={s}>{s}</option>)}
              </select>
            ) : (
              <span style={{ background:st.bg, color:st.color, fontSize:11, fontWeight:700, borderRadius:20, padding:"3px 10px", whiteSpace:"nowrap" }}>
                {item.status === "進行中" && <span className="pulse" style={{display:"inline-block",marginRight:4}}>●</span>}
                {item.status}
              </span>
            )}
          </div>
        );
      })}
    </div>
  );
}

/* ─── AnnouncementView ──────────────────────────────── */
function AnnouncementView({ announcements, isAdmin, onAdd, onDelete }) {
  const [text, setText] = useState("");
  function submit() {
    if (!text.trim()) return;
    onAdd(text.trim());
    setText("");
  }
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
      {isAdmin && (
        <div style={{ display:"flex", gap:8 }}>
          <input value={text} onChange={e=>setText(e.target.value)}
            onKeyDown={e=>e.key==="Enter"&&submit()}
            placeholder="輸入公告內容後按 Enter 或點發布..."
            style={{ flex:1, background:C.surface, border:`1px solid ${C.orange}40`, borderRadius:12, padding:"10px 14px", color:C.text, fontSize:14, outline:"none" }}
          />
          <button onClick={submit}
            style={{ background:C.orange, color:"#fff", border:"none", borderRadius:12, padding:"10px 20px", fontWeight:700, fontSize:14 }}>發布</button>
        </div>
      )}
      {announcements.length === 0 && (
        <div style={{ textAlign:"center", color:C.dim, padding:"40px 0", fontSize:14 }}>目前沒有公告</div>
      )}
      {announcements.map(a => (
        <div key={a.id} className="fade-in" style={{ ...card(), padding:"14px 18px" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", gap:8 }}>
            <div>
              <div style={{ fontSize:11, color:C.orange, fontWeight:700, marginBottom:4 }}>{a.time}</div>
              <div style={{ fontSize:14, color:C.text, lineHeight:1.6 }}>{a.text}</div>
            </div>
            {isAdmin && (
              <button onClick={()=>onDelete(a.id)}
                style={{ background:"transparent", border:"none", color:C.dim, cursor:"pointer", fontSize:16, padding:2, flexShrink:0 }}>✕</button>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

/* ─── LoginModal ────────────────────────────────────── */
function LoginModal({ onLogin, onClose }) {
  const [pw, setPw] = useState("");
  const [err, setErr] = useState(false);
  function attempt() {
    if (pw === CONFIG.adminPassword) { onLogin(); onClose(); }
    else { setErr(true); setTimeout(()=>setErr(false),2000); }
  }
  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.8)", backdropFilter:"blur(4px)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:100, padding:16 }}>
      <div style={{ ...card({ border:`1px solid ${C.orange}40` }), padding:28, width:"100%", maxWidth:320 }}>
        <div style={{ fontSize:18, fontWeight:800, marginBottom:4 }}>🔐 工作人員登入</div>
        <div style={{ fontSize:13, color:C.muted, marginBottom:20 }}>輸入管理員密碼以更新比分與狀態</div>
        <input type="password" placeholder="密碼" value={pw}
          onChange={e=>{setPw(e.target.value);setErr(false);}}
          onKeyDown={e=>e.key==="Enter"&&attempt()}
          style={{
            width:"100%", background:"#1e293b", border:`1px solid ${err ? "#ef4444" : C.border}`,
            borderRadius:10, padding:"10px 14px", color:C.text, fontSize:14, outline:"none",
            marginBottom:err?4:16, transition:"border-color 0.2s",
          }}
        />
        {err && <div style={{ color:"#ef4444", fontSize:12, marginBottom:12 }}>密碼錯誤，請再試一次</div>}
        <div style={{ display:"flex", gap:8 }}>
          <button onClick={onClose} style={{ flex:1, background:"transparent", border:`1px solid ${C.border}`, color:C.muted, borderRadius:10, padding:"10px 0", fontSize:14, cursor:"pointer" }}>取消</button>
          <button onClick={attempt} style={{ flex:1, background:C.orange, color:"#fff", border:"none", borderRadius:10, padding:"10px 0", fontSize:14, fontWeight:700, cursor:"pointer" }}>登入</button>
        </div>
        <div style={{ marginTop:16, textAlign:"center", color:C.dim, fontSize:11 }}>Demo 密碼：bball2024</div>
      </div>
    </div>
  );
}

/* ─── Main App ──────────────────────────────────────── */
export default function App() {
  const [tab, setTab] = useState("bracket");
  const [isAdmin, setIsAdmin] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [rounds, setRounds] = useState(() => buildBracket(CONFIG.teams));
  const [schedule, setSchedule] = useState(INITIAL_SCHEDULE);
  const [announcements, setAnnouncements] = useState(INITIAL_ANNOUNCEMENTS);
  let annIdRef = { current: 100 };

  const updateMatchScore = useCallback((matchId, s1, s2) => {
    setRounds(prev => {
      const next = prev.map(r => ({
        ...r,
        matches: r.matches.map(m => {
          if (m.id !== matchId) return m;
          const winner = s1 > s2 ? m.team1 : s2 > s1 ? m.team2 : null;
          return { ...m, score1: s1, score2: s2, winner };
        }),
      }));
      return propagateWinners(next);
    });
  }, []);

  const tabs = [
    { key:"bracket",  label:"🏆 晉級圖" },
    { key:"schedule", label:"📅 賽程表" },
    { key:"announce", label:"📢 公告" },
  ];

  const liveCount = schedule.filter(s=>s.status==="進行中").length;

  return (
    <div style={{ minHeight:"100vh", background:C.bg }}>
      {/* ── Header ── */}
      <div style={{
        background:"linear-gradient(135deg, #0f172a 0%, #1a0a00 50%, #0f172a 100%)",
        borderBottom:`1px solid ${C.border}`,
        position:"sticky", top:0, zIndex:10,
      }}>
        <div style={{ maxWidth:900, margin:"0 auto", padding:"16px 16px 0" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:12 }}>
            <div>
              <div style={{ fontSize:10, color:C.orange, fontWeight:800, letterSpacing:"0.3em", textTransform:"uppercase", marginBottom:4 }}>
                {CONFIG.eventSubtitle}
              </div>
              <h1 style={{ fontSize:24, fontWeight:900, letterSpacing:"-0.02em", lineHeight:1 }}>
                {CONFIG.eventName.split(" ").map((w,i)=>(
                  <span key={i} style={{ color: i===1 ? C.orange : C.text }}>{w}{" "}</span>
                ))}
              </h1>
            </div>
            <div style={{ display:"flex", flexDirection:"column", alignItems:"flex-end", gap:6 }}>
              {isAdmin ? (
                <button onClick={()=>setIsAdmin(false)} style={{
                  background:"rgba(249,115,22,0.15)", border:`1px solid ${C.orange}60`,
                  color:C.orange, borderRadius:20, padding:"5px 12px", fontSize:12, fontWeight:700,
                }}>✅ 管理員模式</button>
              ) : (
                <button onClick={()=>setShowLogin(true)} style={{
                  background:"rgba(255,255,255,0.05)", border:`1px solid ${C.border}`,
                  color:C.muted, borderRadius:20, padding:"5px 12px", fontSize:12, cursor:"pointer",
                }}>🔐 工作人員</button>
              )}
              <div style={{ display:"flex", alignItems:"center", gap:5 }}>
                <div style={{ width:7, height:7, borderRadius:"50%", background:C.green }} className="pulse" />
                <span style={{ fontSize:10, color:C.green, fontWeight:700 }}>
                  {liveCount > 0 ? `${liveCount} 場進行中` : "即時更新"}
                </span>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div style={{ display:"flex", borderTop:`1px solid ${C.border}`, marginLeft:-16, marginRight:-16 }}>
            {tabs.map(t => (
              <button key={t.key} onClick={()=>setTab(t.key)} style={{
                flex:1, padding:"12px 8px", fontSize:13, fontWeight:700, border:"none", cursor:"pointer",
                background:"transparent",
                color: tab===t.key ? C.orange : C.dim,
                borderBottom: tab===t.key ? `2px solid ${C.orange}` : "2px solid transparent",
                transition:"all 0.2s",
              }}>{t.label}</button>
            ))}
          </div>
        </div>
      </div>

      {/* ── Content ── */}
      <div style={{ maxWidth:900, margin:"0 auto", padding:16 }}>
        {tab === "bracket" && (
          <div>
            <div style={{ fontSize:12, color:C.dim, marginBottom:12 }}>← 左右滑動查看完整晉級圖</div>
            <BracketView rounds={rounds} isAdmin={isAdmin} onUpdate={updateMatchScore} />
          </div>
        )}
        {tab === "schedule" && (
          <ScheduleView schedule={schedule} isAdmin={isAdmin}
            onStatusUpdate={(id, status) => setSchedule(prev => prev.map(s => s.id===id ? {...s, status} : s))} />
        )}
        {tab === "announce" && (
          <AnnouncementView
            announcements={announcements}
            isAdmin={isAdmin}
            onAdd={text => {
              const now = new Date();
              const time = `${String(now.getHours()).padStart(2,"0")}:${String(now.getMinutes()).padStart(2,"0")}`;
              setAnnouncements(prev => [{ id: Date.now(), time, text }, ...prev]);
            }}
            onDelete={id => setAnnouncements(prev => prev.filter(a => a.id !== id))}
          />
        )}
      </div>

      {showLogin && <LoginModal onLogin={()=>setIsAdmin(true)} onClose={()=>setShowLogin(false)} />}
    </div>
  );
}
