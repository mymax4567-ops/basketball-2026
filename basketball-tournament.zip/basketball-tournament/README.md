# 🏀 籃球錦標賽即時賽事平台

掃描 QR Code 即可查看即時賽況、晉級圖、賽程表與公告。

## 功能
- 🏆 **晉級圖** — 16隊單淘汰，勝者自動晉級
- 📅 **賽程表** — 含場地、時間、即時狀態
- 📢 **公告欄** — 工作人員即時發布通知
- 🔐 **管理員模式** — 密碼保護，只有工作人員可更新比分

---

## 🚀 部署到 GitHub Pages（5分鐘完成）

### 步驟一：上傳到 GitHub

1. 在 GitHub 建立新的 Repository（例如 `basketball-2024`）
2. 把整個資料夾上傳上去（或用 git push）

### 步驟二：設定部署

在 `package.json` 第3行，把 homepage 改成你的網址：
```json
"homepage": "https://你的帳號.github.io/basketball-2024"
```

### 步驟三：安裝並部署

在終端機執行：
```bash
npm install
npm run deploy
```

執行完後去 GitHub → Settings → Pages，
選 Branch: `gh-pages` → Save

幾分鐘後就能用 `https://你的帳號.github.io/basketball-2024` 開啟！

---

## 📲 製作 QR Code

1. 去 [qrcode-monkey.com](https://www.qrcode-monkey.com)
2. 貼上你的 GitHub Pages 網址
3. 可以選橘色系配色 + 籃球 logo
4. 下載 PNG 或 SVG → 印出來貼在現場

---

## ⚙️ 客製化設定

打開 `src/App.js`，最上方有設定區：

```javascript
const CONFIG = {
  eventName: "SLAM DUNK CUP",       // 活動名稱
  eventSubtitle: "2024 籃球錦標賽",  // 副標題
  adminPassword: "bball2024",        // ← 改成自己的密碼！
  teams: [
    "火箭隊", "雷霆隊", ...           // 填入你的隊伍名稱（16隊）
  ],
};
```

賽程時間在 `INITIAL_SCHEDULE` 陣列修改。

---

## 注意事項

- 這是**純前端靜態網站**，資料儲存在使用者瀏覽器記憶體
- 每次關閉瀏覽器比分會重置 → 適合**活動當天工作人員開著不關閉**使用
- 如需跨裝置同步比分，建議之後升級加入 Firebase（可另外諮詢）
